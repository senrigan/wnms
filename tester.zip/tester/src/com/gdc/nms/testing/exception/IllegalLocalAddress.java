package com.gdc.nms.testing.exception;

public class IllegalLocalAddress extends Exception {
    public IllegalLocalAddress(String message) {
        super(message);
    }
}
