package com.gdc.nms.testing.exception;

public class TimeoutException extends RuntimeException {

}
