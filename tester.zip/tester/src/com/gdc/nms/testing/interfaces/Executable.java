package com.gdc.nms.testing.interfaces;

public interface Executable {
    public void start();

    public void stop();

    public boolean isRunning();
}
